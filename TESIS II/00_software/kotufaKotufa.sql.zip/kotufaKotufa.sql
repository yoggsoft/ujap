-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 17-01-2011 a las 22:28:51
-- Versión del servidor: 5.1.53
-- Versión de PHP: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `kotufa`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE IF NOT EXISTS `alumno` (
  `cedula` varchar(10) NOT NULL,
  `nombreal` varchar(30) NOT NULL,
  `dir` varchar(84) NOT NULL DEFAULT '',
  `tel` varchar(11) NOT NULL,
  `colegio` varchar(30) NOT NULL,
  PRIMARY KEY (`cedula`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`cedula`, `nombreal`, `dir`, `tel`, `colegio`) VALUES
('17079726', 'Manuel Reyes', 'Trigal Norte\r\n#88-21\r\nCalle Acuario', '04144223616', 'Los Robles'),
('16789234', 'wes borland', 'los angeles california', '800342567', 'berkley'),
('33045354', 'Valeria Tallone', 'Gorriti 376 3-A', '0415547754', 'Dante Alighieri');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clase`
--

CREATE TABLE IF NOT EXISTS `clase` (
  `idclase` varchar(10) NOT NULL,
  `fecha` varchar(15) NOT NULL,
  `nprofesor` varchar(30) NOT NULL,
  `nalumno` varchar(30) NOT NULL,
  `horas` int(1) NOT NULL,
  `contenido` longtext NOT NULL,
  `subtotal` int(10) NOT NULL,
  `total` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `clase`
--

INSERT INTO `clase` (`idclase`, `fecha`, `nprofesor`, `nalumno`, `horas`, `contenido`, `subtotal`, `total`) VALUES
('0001', '', 'Fabiola Angulo', 'Manuel Reyes', 4, '', 72000, 92000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `cedula` varchar(10) NOT NULL,
  `nombrep` varchar(50) NOT NULL,
  `dir` varchar(84) NOT NULL DEFAULT '',
  `tel` varchar(11) NOT NULL,
  `materia` varchar(30) NOT NULL,
  `horario` varchar(50) NOT NULL,
  PRIMARY KEY (`cedula`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`cedula`, `nombrep`, `dir`, `tel`, `materia`, `horario`) VALUES
('17664532', 'Javier Molina', 'Urb. Prebo', '04143435843', 'Matemática', '4:00/6:00pm'),
('7685234', 'alirio gonzales', 'el morro sector los arales', '8764512', 'Química', '3:00/7:00pm'),
('1111111', 'Fabiola Angulo', 'el parral edif clarinete', '0416448444', 'Física', '6:30/9:00pm');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

CREATE TABLE IF NOT EXISTS `materia` (
  `idmat` varchar(10) NOT NULL,
  `nombre` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `materia`
--

INSERT INTO `materia` (`idmat`, `nombre`) VALUES
('mat1c', 'Matematicas 1 C'),
('bio6g', 'Biologia 6 g'),
('fis9g', 'Fisica 9 grado'),
('SIF07', 'Sistemas de Inf'),
('mat6g', 'Matematica 6 gr'),
('log01', 'logica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materiaasignada`
--

CREATE TABLE IF NOT EXISTS `materiaasignada` (
  `idasigna` int(10) NOT NULL DEFAULT '0',
  `idmateria` varchar(10) NOT NULL,
  `idprofesor` varchar(10) NOT NULL,
  `idalumno` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `materiaasignada`
--

INSERT INTO `materiaasignada` (`idasigna`, `idmateria`, `idprofesor`, `idalumno`) VALUES
(7, 'log01', '7685234', '16789234'),
(6, 'fis9g', '17664532', '17079726'),
(3, 'mat1c', '1111111', '17079726'),
(4, 'SIF07', '17664532', '17079726'),
(5, 'fis9g', '17664532', '16789234'),
(8, 'bio6g', '17664532', '33045354');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `idusuario` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `cedula` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idusuario`, `password`, `tipo`, `cedula`) VALUES
('admin', 'admin', 'Administrador', ''),
('jmolina', 'jmolina', 'Profesor', '17664532'),
('mreyes', 'mreyes', 'Alumno', '17079726'),
('wborland', 'wborland', 'Alumno', '16789234'),
('fangulo', 'fangulo', 'Profesor', '1111111'),
('agonzales', 'agonzales', 'Profesor', '7685234'),
('vtallone', 'vtallone', 'Alumno', '33045354');
